---@type BattleNetwork.Assets
local bn_assets = require("BattleNetwork.Assets")
---@type dev.konstinople.library.turn_based
local TurnBasedLib = require("dev.konstinople.library.turn_based")

local battle_helpers = require("battle_helpers.lua")

local WAVE_TEXTURE = Resources.load_texture("shockwave.png")
local WAVE_ANIM_PATH = "shockwave.animation"
local WAVE_SFX = bn_assets.load_audio("shockwave.ogg")
local GUARD_HIT_TEXTURE = bn_assets.load_texture("shield_impact.png")
local GUARD_HIT_ANIM_PATH = bn_assets.fetch_animation_path("shield_impact.animation")
local TINK_SFX = bn_assets.load_audio("guard.ogg")

local function debug_print(text)
    --print("[mettaur] " .. text)
end

local turn_tracker = TurnBasedLib.new_directional_tracker()

local TEXTURE = Resources.load_texture("battle.greyscaled.png")

function character_init(self, character_info)
    debug_print("character_init called")
    -- Required function, main package information

    -- Load character resources
    local animation = self:animation()
    animation:load("battle.animation")

    -- Load extra resources

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_texture(TEXTURE)
    self:set_height(character_info.height)
    self:enable_sharing_tile(false)
    self:set_palette(Resources.load_texture(character_info.palette))

    --defense rules
    self:add_aux_prop(StandardEnemyAux.new())

    -- Initial state
    animation:set_state("IDLE")
    animation:set_playback(Playback.Loop)
    self.frames_between_actions = character_info.move_delay
    self.cascade_delay = character_info.cascade_delay               --lower = faster shockwaves
    self.shockwave_frame_time = character_info.shockwave_frame_time --lower = faster shockwaves
    self.shockwave_damage = character_info.damage
    self.can_guard = character_info.can_guard
    self.replacement_panel = character_info.replacement_panel
    self.ai_wait = self.frames_between_actions
    self.ai_taken_turn = false

    self.on_idle_func = function()
        animation:set_state("IDLE")
        animation:set_playback(Playback.Loop)
    end

    self.on_update_func = function(self)
        if turn_tracker:request_turn(self) then
            take_turn(self)
        else
            idle_action(self)
        end
    end

    self.on_battle_start_func = function(self)
        debug_print("battle_start_func called")

        local field_height = Field.height()

        ---@param a Entity
        ---@param b Entity
        local mob_sort_func = function(a, b)
            local met_a_tile = a:current_tile()
            local met_b_tile = b:current_tile()
            local var_a = (met_a_tile:x() * field_height) + met_a_tile:y()
            local var_b = (met_b_tile:x() * field_height) + met_b_tile:y()
            return var_a < var_b
        end
        turn_tracker:sort_turn_order(function(a, b)
            if a:facing() == Direction.Left then
                return mob_sort_func(a, b)
            else
                -- reversed sort direction
                return mob_sort_func(b, a)
            end
        end)
    end
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        turn_tracker:add_entity(self)
    end
end

function find_target(self)
    local team = self:team()
    local target_list = Field.find_characters(function(entity)
        if not entity:hittable() then return false end

        return entity:team() ~= team
    end)
    if #target_list == 0 then
        debug_print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

function idle_action(self)
    if self.can_guard then
        --if the mettaur can guard, queue up a guard for after the current action
        if self.guarding_defense_rule then
            local anim = self:animation()
            anim:set_state("GUARD_PERSIST")
        elseif not self.guard_transition then
            begin_guard(self)
        end
    end
end

function end_guard(character)
    character.guard_transition = true
    local anim = character:animation()
    anim:set_state("GUARD_END")
    anim:set_playback(Playback.Once)
    character:remove_defense_rule(character.guarding_defense_rule)
    character.guarding_defense_rule = nil
    anim:on_complete(function()
        character.guard_transition = false
    end)
end

function begin_guard(character)
    character.guard_transition = true
    local anim = character:animation()
    anim:set_state("GUARD_START")
    anim:set_playback(Playback.Once)

    anim:on_complete(function()
        character.guard_transition = false
        character.guarding_defense_rule = DefenseRule.new(DefensePriority.Last, DefenseOrder.Always)
        character.guarding_defense_rule.defense_func = function(defense, attacker, defender, attacker_hit_props)
            if attacker_hit_props.flags & Hit.Drain ~= 0 or attacker_hit_props.flags & Hit.PierceGuard ~= 0 then
                --cant block breaking hits with guard
                return
            end
            defense:set_responded()
            defense:block_damage()
            if attacker_hit_props.damage > 0 then
                Resources.play_audio(TINK_SFX, AudioBehavior.Default)
                battle_helpers.spawn_visual_artifact(character, character:current_tile(), GUARD_HIT_TEXTURE,
                    GUARD_HIT_ANIM_PATH, "DEFAULT", 0, -30)
            end
        end
        character:add_defense_rule(character.guarding_defense_rule)
    end)
end

function take_turn(self)
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        if not self.guarding_defense_rule and not self.guard_transition and not self.shockwave_action then
            local anim = self:animation()
            anim:set_state("IDLE")
        end
        return
    end
    self.ai_taken_turn = true

    if self.guarding_defense_rule and not self.guard_transition then
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        end_guard(self)
        return
    end

    local moved = move_towards_character(self)
    if moved then
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        return
    end
    self.shockwave_action = action_shockwave(self)
    self.shockwave_action.on_action_end_func = function()
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        self.shockwave_action = nil
        turn_tracker:end_turn(self)
    end
    self:queue_action(self.shockwave_action)
end

function move_towards_character(self)
    local target_character = find_target(self)
    if not target_character then return false end

    local target_character_tile = target_character:current_tile()
    local tile = self:current_tile()
    local target_movement_tile = nil
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down, 1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up, 1)
    end
    if not target_movement_tile or not self:can_move_to(target_movement_tile) then
        return false
    end

    local move_artifact = bn_assets.MobMove.new("MEDIUM_START")
    move_artifact:set_offset(0, -self:height() // 2)
    move_artifact:sprite():set_layer(-1)
    move_artifact:animation():on_frame(2, function()
        self:teleport(target_movement_tile)
    end)
    Field.spawn(move_artifact, tile)

    return true
end

function action_shockwave(character)
    local action_name = "shockwave"
    local facing = character:facing()
    debug_print('action ' .. action_name)

    local action = Action.new(character, "ATTACK")
    action:set_lockout(ActionLockout.new_animation())
    action.on_execute_func = function(self, user)
        self:on_anim_frame(6, function()
            character:set_counterable(true)
        end)
        self:on_anim_frame(12, function()
            local tile = character:get_tile(facing, 1)
            spawn_shockwave(character, tile, facing)
        end)
        self:on_anim_frame(13, function()
            character:set_counterable(false)
        end)
    end
    return action
end

function spawn_shockwave(owner, tile, direction)
    local team = owner:team()
    local damage = owner.shockwave_damage
    local context = owner:context()
    local cascade_delay = owner.cascade_delay
    local new_tile_state = owner.replacement_panel

    local frame_data = {}

    for i = 1, 5 do
        local frame_time = owner.shockwave_frame_time

        if i >= 4 and frame_time < 5 then
            frame_time = frame_time + 1
        end

        frame_data[i] = { i, frame_time }
    end

    local function spawn_next()
        if not tile or not tile:is_walkable() then return end

        if tile:state() == new_tile_state and new_tile_state == TileState.Cracked then
            tile:set_state(TileState.Broken)
            return
        elseif new_tile_state then
            tile:set_state(new_tile_state)
        end

        Resources.play_audio(WAVE_SFX, AudioBehavior.Default)

        local spell = Spell.new(team)
        spell:set_facing(direction)
        spell:set_tile_highlight(Highlight.Solid)
        spell:set_hit_props(HitProps.new(
            damage,
            Hit.Flinch | Hit.Flash,
            Element.None,
            context,
            Drag.new()
        ))

        local sprite = spell:sprite()
        sprite:set_texture(WAVE_TEXTURE)
        sprite:set_layer(-1)

        local animation = spell:animation()
        animation:load(WAVE_ANIM_PATH)
        animation:set_state("DEFAULT", frame_data)
        animation:apply(sprite)
        animation:on_complete(function()
            spell:erase()
        end)

        local next_spawn_delay = cascade_delay
        spell.on_update_func = function()
            next_spawn_delay = next_spawn_delay - 1
            if next_spawn_delay == 0 then
                tile = spell:get_tile(spell:facing(), 1)
                spawn_next()
            end

            local current_tile = spell:current_tile()

            if not current_tile:is_walkable() then
                spell:delete()
                return
            end

            spell:attack_tile()
        end

        Field.spawn(spell, tile)
    end

    spawn_next()
end

return character_init
