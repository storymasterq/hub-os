local shared_character_init = require("../shared/entry.lua")

function character_init(character)
    local character_info = {
        name = "Mettaur",
        hp = 40,
        damage = 10,
        palette = Resources.load_texture("battle_v1.palette.png"),
        height = 19,
        cascade_delay = 21,
        shockwave_frame_time = 5,
        move_delay = 38,
        can_guard = true,
        replacement_panel = nil
    }
    if character:rank() == Rank.V1 then
        character_info.can_guard = false
    end
    if character:rank() == Rank.V2 then
        character_info.damage = 30
        character_info.cascade_delay = 16
        character_info.shockwave_frame_time = 3
        character_info.palette = Resources.load_texture("battle_v2.palette.png")
        character_info.hp = 80
        character_info.move_delay = 32
    elseif character:rank() == Rank.V3 then
        character_info.damage = 50
        character_info.palette = Resources.load_texture("battle_v3.palette.png")
        character_info.hp = 120
        character_info.cascade_delay = 11
        character_info.shockwave_frame_time = 3
        character_info.move_delay = 26
    elseif character:rank() == Rank.SP then
        -- timing is guessed on this rank
        character_info.damage = 70
        character_info.palette = Resources.load_texture("battle_vsp.palette.png")
        character_info.hp = 160
        character_info.cascade_delay = 13
        character_info.shockwave_frame_time = 3
        character_info.move_delay = 24
    elseif character:rank() == Rank.Rare1 then
        character_info.damage = 50
        character_info.palette = Resources.load_texture("battle_vrare1.palette.png")
        character_info.hp = 120
        character_info.cascade_delay = 16
        character_info.shockwave_frame_time = 3
        character_info.move_delay = 26
        character_info.replacement_panel = TileState.Cracked
    elseif character:rank() == Rank.Rare2 then
        character_info.damage = 100
        character_info.palette = Resources.load_texture("battle_vrare2.palette.png")
        character_info.hp = 180
        character_info.cascade_delay = 5
        character_info.shockwave_frame_time = 2
        character_info.move_delay = 24
        character_info.replacement_panel = TileState.Poison
    end
    shared_character_init(character, character_info)
end
